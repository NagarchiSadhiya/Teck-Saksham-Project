How to run the Online College Assignment System Project Using PHP and MySQL

1.Download the zip file

2.Extract the file and copy ocas folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4.Open PHPMyAdmin (http://localhost/phpmyadmin)

5.Create a database with name ocasdb

6.Import ocasdb.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/ocas

Admin Credential
Username: admin
Password: Test@123

Teacher Credential
Username: EMP12345
Password: Test@123
or Register a new  Teacher through admin panel


User Credential
Username: test@gmail.com
Password: Test@123
or Register a new user